# # ------------------ List ----------------------
# # In case of Single Data type
# marks=[87,64,95,78]
# print(marks)
# # Can Also Add Multiple Data Type 
# stu=["Ali",34,"Ahmad",98]
# print(stu[0]," : ",stu[1])

# # Strings are Immutable ( Non Change ) while Lists are mutable ( Changable )
# # EG of String :
# str="Hello"
# print(str[0]) # Allows it
# str[0]=="a" # Not Allowed and not works
# print(str) 
# # EG of List :
# l1=[1,2,3,4]
# l1[0]="Ahmad"
# print(l1)
# # In Case we try to excess non member index in list it will show error

# # ------------------ Slicing Of List ----------------------
# # Default Values === >> list[0:Len(list):1]
# # Syntex : list[Stating point : Last Point : Jumping Value]
# # ------------ Positive Indexing
# marks=[1,2,3,4,5,6,7,8,9]
# print(marks[0:5:2])
# # ---------- Negative Indexing
# print(marks[-9:len(marks)])

# #-------------------- list Functions ---------------------

# ------------- Append ( To add New Values in List )
# name=["Ahmad","Ali","Harry","Tabasum"]
# print(name)
# name.append("Tooba")
# print(name)

# # #------------ Sort Function -------------
# #Sort both Numbers and Strings in ascending order
# #Sort String List
# #In Case of Sorting There will be one data type in list
# name=["12","Harry","Ahmad","Ali","Tabasum"]
# name.sort()
# print(name)
# #Sort Number
# num=[23,24,2,4124,21,4,124,124,21,4,2314,21,412,4,234]
# num.sort()
# print(num)

# # Reverse Sorting
# # Sort both Numbers and Strings in Descending order
# list1=[1,2,3,4,5,6,7,8,9]
# list1.sort(reverse=True)
# print(list1)

# # --------------- reverse Function -----------------
# # To print List in Descending Order
# list1=[213,12421,4,124,214,21,4,2145,124,1254,1,4,521,12,54,1,412,45,12,521,5,15,312,512,45,125,1,215,213,5,152,3]
# list1.reverse()
# print(list1)
# Works for both string , num amd both
# list2=["Ahmad","Ali","harry"]
# list2.reverse()
# print(list2)
# Incase of Both
# list3=["Ahmad","Ali","harry",1,2,3,4,5,6,7,8,9]
# list3.reverse()
# print(list3)

# # # ----------------- Insert(Index,Value)------------
# list3=["Ahmad","Ali","harry",1,2,3,4,5,6,7,8,9]
# list3.insert(1,"Potter")
# print(list3)

# # ------------------ Remove Function -------------
# # Syntax ===>> list_name.remove(Variable_name)
# # And It removes Only First Occurance
# list3=["Ahmad","Ali","harry",1,2,3,4,5,6,7,8,9,"Ali"]
# list3.remove("Ali")
# print(list3)

# # -------------------- Pop Function ----------------
# # It Actualy Removes Variablefrom  a specific Index
# # Syntax ===== >>> List_name.pop(Index)
# list3=["Ahmad","Ali","Harry",1,2,3,4,5,6,7,8,9]
# list3.pop(1)
# print(list3)

######=================================================================================================

# # # ----------------------- Tuple ------------------------
# # #A built in data type that lets us creat immuteble (Not changeable) list of vaiables
# tup1=(1,2,3,4,5,6,7)
# print(tup1)
# tup2=(1,) # In case of single variable there could be a coma next to it else its data type changes to tye of variable in it
# print(type(tup2))

# # # --------------- Slicing in Tuple ---------------------
# #--------- Positive indexing ------------
# tup1=(1,2,3,4,5,6,7)
# print(tup1[0:8])
# # ------- Negative Indexing -------------
# tup2=(2,4,6,8,10,12,14,16,18,20)
# print(tup2[-10:-8])

# #---------------------- Functions ---------------------

# # -------------- Index ( ) -------------
# # To find first Occuring Index of Variable 
# tup=(1,2,3,4,5,6,7,7,7,7,7,2,3,1,3,4,5,6,6,)
# print(tup.index(7))

# # ---------------- Count ( ) ---------------
# # To print No. of Existance of a Variable In Tupple
# tup=(1,2,3,4,5,6,7,7,7,7,7,2,3,1,3,4,5,6,6,)
# print(tup.count(7))


# # -------------------------- Practice ---------------------

# # -------- Task 1
# movie=[]
# m1=str(input("Enter Movie 1 Name : "))
# m2=str(input("Enter Movie 2 Name : "))
# m3=str(input("Enter Movie 3 Name : "))
# movie.append(m1)
# movie.append(m2)
# movie.append(m3)
# print("Movie Name : ",movie)

# # --------- Task 2
# list1=[1,2,3,2,1]
# list2=list1.copy()
# print(list2)
# list1.reverse()
# print(list1)
# if(list2==list1):
#     print("Its Palindrom ")
# else:
#     print("Its Not  palindrom ")