# # Python can read and write in file by file handling 
# # All Types of Files : 
# # 1 . Text File ( Text Data Files ): txt,docx,log,etc
# # 2 . Binary File (Other than Text data Files ) : mp4,mov,png,jpeg,etc
# # Automaticaly creates a file for every mode
# # -------------------- Read file -----------------------
# # syntax === >> f=open("File_name","Mode")
# # Default value of mode === >> Read
# # variable_name = f.read()
# # f.close()
# f=open("New.txt","r")
# data=f.read(5) # No of variables to read
# print(data)
# f.close()

# ---------------- Modes --------------
# r === >> Reading File (Default perimeter)
# w === >> Write in file , truncting( Past data of file is deleted ) the file first
# x === >> Create a new file and open it for writing
# a === >> Open for appending without deleting past data 
# b === >> Binary Mode (open a binary file)
# t === >> open text file( default )
# + === >> To perform 2 operations side by side

# # ------------------ To read line by line ----------------
# f=open("New.txt","r")
# data=f.readline()
# print(data) # As it prints line 1 the next line is empty due to a character " \n " at end of lines
# f.close()
# # In case if we performed read function before readline the read prints all data but readline prints only spaces

# # # ------------- Write Operation -------------------
#  It will over writes and remove old value
# f=open("New.txt","w")
# f.write("Ahmad is a python developer")
# f.close()

# # ------------- Write with append Mode ----------------
# # It will add data to past one 
# f=open("New.txt","a")
# # To move the data to next line we use " \n "
# f.write("\nHe is also good in C++ ")
# f.close()

# # # ------------- r+ Mode ( Read and write ) ----------------
# # File Not truncates in r+
# f=open("New.txt","r+")
# f.write("He will learn JS After Python ")
# print(f.read()) # Starts Reading from where the cursor stops
# f.close()

# # ------------- W+ mode (Read and Write )----------------
# # But it will truncates 
# f=open("New.txt","w+")
# print(f.read())
# f.write("Ahmad is a Python developer")
# print(f.read())
# f.close()

# # ------------- a+ mode (Read and Append ) --------------------
# f=open("New.txt","a+")
# print(f.read())
# f.write("\nHe is also good in C++ ")
# print(f.read())
# f.close()

# # ------------------ With Function ----------------
# with open("New.txt","r") as f:
#     data=f.read()
#     print(data)
# # by this function closes file automaticaly
# with open("New.txt","r+") as f:
#     f.write("Hello Ahmad")
#     print(f.read())

# # --------------- Delete a file -------------
# # Syntax :
# # import os
# # os.remove("File name")
# # -------------------------------------
# import os
# os.remove("n1.txt")