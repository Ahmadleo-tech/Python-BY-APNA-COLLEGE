# ==================== Match Case Statements in Python 3.10 ================= 
# As like switch in c++
# ================= Basic Syntax =============
# x=2
# match x :
#     case 0:
#         print("Its Zero")
        
#     case 4:
#         print("Its Four")
#     case _:
#         print("Invalid Input ")
#------------------------------------ Tasks ------------------------------
# ======= Task 1
# m=int(input("Enter Number of Month : "))
# match m:
#     case 1:
#         print("Month No. ",m," is January")
#     case 2:
#         print("Month No. ",m," is Febuary")
#     case 3:
#         print("Month No. ",m," is March")
#     case 4:
#         print("Month No. ",m," is April")
#     case 5:
#         print("Month No. ",m," is May")
#     case 6:
#         print("Month No. ",m," is June")
#     case 7:
#         print("Month No. ",m," is July") 
#     case 8:
#         print("Month No. ",m," is August")
#     case 9:
#         print("Month No. ",m," is Septamber")
#     case 10:
#         print("Month No. ",m," is Octuber")
#     case 11:
#         print("Month No. ",m," is November")
#     case 12:
#         print("Month No. ",m," is December")
#     case _:
#         print(m," is An Invalid input ")

# ======= Task 2
# m=int(input("Enter Number of Day : "))
# match m:
#     case 1:
#         print("Day No. ",m," is Monday")
#     case 2:
#         print("Day No. ",m," is Tuesday")
#     case 3:
#         print("Day No. ",m," is Wednersday")
#     case 4:
#         print("Day No. ",m," is Thursday")
#     case 5:
#         print("Day No. ",m," is Friday")
#     case 6:
#         print("Day No. ",m," is Saturday") 
#     case 7:
#         print("Day No. ",m," is Sunday")
#     case _:
#         print(m," is An Invalid input ")
#------------------------------------ Match (Cases + condition) ------------------------------
# We also add condition to any cases
#------------------------------------ Tasks ------------------------------
# ======== task 1
# m=int(input("Enter A Number : "))
# match m:
#     case 0:
#         print(m," is an Even Number ")
#     case 1:
#         print(m," is an Odd Number")
#     case _ if(m%2==0):
#         print(m," is an Even Number ")
#     case _ if(m%2!=0):
#         print(m," is an Odd Number")
#========= task 2
# c=str(input("Enter Char To check either its Vowel or Consonent : "))
# match c:
#     case _ if(c=='a' or c=='e' or c=='i' or c=='o' or c=='u' or c=='A' or c=='E' or c=='I' or c=='O' or c=='U'):
#         print(c," is a Vowel Character ")
#     case _ :
#         print(c," is a consonent" )