# #============= Strings details ===================
# # Default Variable String
# # String is a sequence of characters introduced in double or single cout
# a="He Said , "
# # Way one Use Escape Symbols to use double cors in double cours
# b="\"I want to eat the apple\""
# print("For Escape Symbols : ",a+b)
# #Second Way is To Introuce String in single course
# c='"I want to eat the apple"'
# print("For Single Cores : ",a+c)
# # Every thing in triple single or double cors is consider as a string
# print('''Hello 
# Ahmad 
# Ali
# Harry
# I hope You wll be Fine''')
# # To Print String by Character string ==> indexing eg: a="Ali"
# # To Print Character wise == >> print(a[0]),print(a[1]),print(a[1])
# name="Harry"
# print(name[0])
# print(name[1])
# print(name[2])
# print(name[3])
# print(name[4])
# #print(name[5]) Error
# #===================== Loop ======================
# print("Loop : ")
# for char in name:
#   print(char)
# # ------------------------- Use of Scices in Strings ----------------------------
# fruit = "Mango"
# mangoLen = len(fruit)
# print(mangoLen)
# # print(fruit[0:4]) # including 0 but not 4
# # print(fruit[1:4]) # including 1 but not 4
# # print(fruit[:5])
# # print(fruit[0:-3])
# # print(fruit[:len(fruit)-3])
# print(fruit[-1:len(fruit) - 3])
# print(fruit[-3:-1])

# # --------------- Task ------------------
# mn="Ahmad"
# print(mn[-4:-2])
# # --------------------- All Inbuilt String Functions ---------------------------
# # # String Methods in Python
# # # String are Immutable
# # a="Ahmad"
# # # ================= len( variable ) =====================
# # # Print Length of String
# # print(len(a))
# # # ================= lower( ) + Upper ( ) =====================
# # # Make the string in upper case but creat a new copy of upper case 
# # print(a.upper())
# # # Make the string in upper case but creat a new copy of lower case
# # print(a.lower())
# # # ================= Rstrip( ) =====================
# # # For rstrip or removing any thing
# # a1="Ali!!!!!!!!!!!!!!"
# # print(a1.rstrip("!"))
# # # But Not Remove if it is before string 
# # a2="!!!!!! Hello !!!! Hello !!!!!!!! Hello "
# # print(a2.rstrip("!"))
# # # ================== Replace ( ) ===================
# # # For replacing All occerances we use replace function()
# # print(a2.replace("Hello","Ahmad"))
# # # =================== Split( ) =======================
# # # To make a string in list  But the reqirement is there would be space by them the list members == No. of Spaces + 1
# # # For this we use split function
# # print(a2.split())
# # # ==================== Captilization ( ) ===================
# # # To Captilize the string Only first letter any all other are small
# # a3="""hello !!
# # ali hoe are you ? ,
# # i am fine and what about your family"""
# # print(a3.capitalize())
# # # ======================= Center ( ) =========================
# # # The center() Function alline string to center as per the peremeter given by user
# # print("Length of A : ",len(a1))  
# # print(a1.center(50))
# # print("Length of A : ",len(a1.center(50)))
# # # ========================= Endswith() =================
# # #  if string.endswith("a") 
# # # if yes == > true 
# # # else == > false
# # a3="ahmad"
# # print(a3.endswith("ahmad"))
# # # ====================== Find ( ) ======================
# # # In find ( ) functio if found then print its index else return -1
# # # if found multiple time the print first ones index
# # print(a3.find("a"))
# # # ======================= isalnum( ) ======================
# # #  It checks that either oyur string is alpha  numbaric or not
# # # these are A - Z , a - z and 0 - 9 === >> if these returns true
# # # else (Other character , symbols , even space ) Return false
# # print(a3.isalnum())
# # # ======================= isalpha( ) ======================
# # #  It checks that either oyur string is alpha  numbaric or not
# # # these are A - Z and a - z  === >> if these returns true
# # # else (Other character , symbols , even space ) Return false
# # print(a3.isalpha())
# # # ======================= islower( ) ======================
# # #  check if the string is in lower case or not 
# # # if yes === >> true
# # # else === >> False
# # print(a3.islower())
# # # ======================= isupper( ) ======================
# # #  check if the string is in upper case or not 
# # # if yes === >> true
# # # else === >> False
# # print(a3.isupper())
# # # ====================== isprintable( ) ===================
# #  #  check if the string is Print able or not 
# # # if yes === >> true
# # # else === >> False
# # print(a3.isprintable())
# # s1="\n"
# # print(s1.isprintable())
# # # ====================== isspaces( ) ===================
# # #  check if the string has White Spaces or not 
# # # if yes === >> true
# # # else   === >> False
# # s2="            "
# # print(s2.isspace())
# # s3="ali"
# # print(s3.isspace())
# # # ====================== istitle( ) ===================
# # #  check if the string all each letter first letter is capitial 
# # # if yes === >> true
# # # else   === >> False
# # s4="Hello Ali"
# # print(s4.istitle())
# # s5="Hello ali"
# # print(s5.istitle())
# # # ========================= Startsswith(  ) =================
# # #  if string.Sndswith("Letter") 
# # # if yes == > true 
# # # else == > false
# # a5="ahmad"
# # print(a5.startswith("a"))
# # print(a5.startswith("h"))
# # # ========================= swapcase( ) =================
# # #  It Swaps the lower case to upper case and vise versa
# # # if yes == > true 
# # # else == > false
# # a6="ahmad"
# # print(a6.swapcase())
# # # ========================= Title( ) =================
# # #  title( ) is a function makes each word's First letter in string 
# # a6="hello ahmad how are you i hope you will be fine."
# # print(a6.swapcase())