# print("Hello")
# =====================While Loop + Continue + break ==================
# count=0 # Iterator
# while(count<=5):
#     print("Hello")
#     count+=1
# i=0
# while(i<=1000):
#     print(i," . Ahmad")
#     i+=1
# ================================================
#===========Task 1
# i=1
# while(i<=100):
#     print(i)
#     i+=1
#===========Task 2
# print("Enter Number : ")
# n=int(input())
# i=0
# while(i<=10):
#     print(n," * ",i," = ",n*i)
#     i+=1
#===========Task 3
# i=100
# while(i>=1):
#     print(i)
#     i-=1
#===========Task 4 (List)
# -----------------------------------------
# list1=[]
# n=int(input("Enter the length of List : "))
# i=0
# while(i<=n):
#     element=input("Enter value for index ", i+1," : ")
#     list1.append(element)
#     i+=1

# while(i<n):
#     print("Value of List at ",i+1," : ",list1[i])
#     i+=1
# ---------------------------------------
# list1=[4,8,9,16,25,36,49,64,81]
# i=0
# while(i<=len(list1)):
#     print(list1[i])
#     i+=1
#---------------------------------------
# Traverse 
# heros=["Iron Man","Thor","hulk","Caption America"]
# i=0
# while(i<=len(heros)):
#     print(heros[i])
#     i+=1
#-------------------------------------
# x=int(input("Enter Number to find in List : "))
# l1=[1,2,3,4,5,6,7,8,9]
# i=0
# while(i<=len(l1)):
#     if(l1[i]==x):
#         print(x," is Found ")
#         break
#     else:
#         print("Not")
#         pass
#     i+=1
#===========Task 5 (Tuble)
# l1=(1,2,3,4,5,6,7,8,9)
# i=0
# while(i<=len(l1)):
#     print(l1[i])
#     i+=1
# i=9
# print("Reverse Tuble : ")
# while(i>=0):
#     print(l1[i])
#     i-=1
#============= Task 6 
# i=0
# print("For Continue Statment : ")
# while(i<=6):
#     print(i)
#     if(i==3):
#         print("The Value Was 3 ")
#         continue
#     i+=1
# print("For Break Statment : ")
# while(i<=6):
#     print(i)
#     if(i==5):
#         print("The Value Was 5 ")
#         break
#     i+=1
# ================= For Loops ====================
# --------- Use of ( For Loop with array ) == >> for variable in list/tuble/dict/array : print(variable)
#  Then it Print all content in list/tuble/dict/array
#==== TAsk 1 
# list1=["Ali","ahmd","hat","asf","dsvaaj"]
# for el in list1:
#     print(el)
#==== TAsk 2
# tuble1=(1,2,3,4,5,6,7)
# for n in tuble1:
#     print(n)
#======== Task 3 
# list1=["apple","banana","pineapple","Dragon"]
# x=str(input("Enter name to Find : "))
# for el in list1:
#     if(x==el):
#         print(el," is found ")
#         break
#======== Task 4 + range function-------------------------------------
# emp=(1,2,3,4,5)
# x=int(input("Enter Number : "))
# for el in range(5):
#     if(x==el):
#         print("Found")
#         break
#======= Task 5 
# i=[1,2,3,4,5,6,7,8,9,10]
# print("With Range ( E ) : ")
# for n in range(10): # Range(stopping index)
#     print(n)
# print("With Range ( S , E ) : ")
# for n in range(2,10): # Range(Starting Index,stopping index)
#     print(n)
# print("With Range ( S , E , J ) : ")
# for n in range(1,10,3): # Range(Starting Index ,stopping index , Increment)
#     print(n)
#========= TAsk 6
# print("Even Numbers : ")
# for e in range(0,100,2):
#     print(e)
# print("Odd Numbers : ")
# for o in range(1,100,2):
#     print(o)
#======== Task 7
# print("Number from 1 - 100 : ")
# for n in range(1,100):
#     print(n)
# ======= Task 8
# print("Number from 1 - 100 : ")
# for n in range(1,100):
#     print(n)
#======== Task 9 
# x=int(input("Enter a number : "))
# for n in range(0,10):
#     print(x," * ", n, " = ",n*x)
#------------------ PAss Statment -------------
# for n in range(2,16):
#     if(n%2==0):
#         print(n)
#     else:
#         pass
# =============================================================================================
# ==========Task 1
# sum=0
# for n in range(1,1000):
#     sum=sum+n
# print(sum)
# list1=[1,2,3,4,5,6,7,8]
# sum1=0
# for n in list1:
#     sum1=sum1+n
# print(sum1)
# ==========TAsk 2
# n=9
# fact=1
# i=1
# while(i<=n):
#     fact*=i
#     i+=1
# print("Factorial of ",n," is : ",fact)
# ======== TAsk 3
# n=8
# fact=1
# for i in range(1,n+1):
#     fact=fact*i
# print("Factorial of ",n," is : ",fact)






