# # -------------------- Dictonary -----------------
# # It is used to store data in key : Value Pair
# # They are unordered , changeable and donot allow duplicate key
# # To store Key type pair value we use ==== >> Dictionary
# dict1={"Name ": "Ahmad Abdullah"
#        ,"CGPA ": 2.9
#        ,"Marks " : [98,97,87]
#      }
# print(dict1)
# # --------------- ReDeclaring and declaring new variable -------------------
# dict1["Name "]="Ahmad Leo" # In this case the last name overwrites
# dict1["Short Name : "]="Ahmad ."
# print(dict1)

# # ------------- Empty Distonary --------------
# null={}
# print(null)

# # -------------- Nested Dictonary -------------
# student={"Name ":"Ali",
#          "marks": {
#              "Phy ": 89,
#              "Chm ": 78,
#              "Bio ":86
#          }
#          }
# # -------- Print whole list
# print(student)
# # Print only name or marks 
# print("Name of Student : ",student["Name "])
# print(student["marks"])
# #print Marks of a subject
# print(student["marks"]["Phy"])
# print(student["marks"]["Chm"])
# print(student["marks"]["Bio"])

# # ---------------------------- Inbuilt Functions -------------------------
# # -------------- Keys() ------------------
# # To print all keys in dict
# student={"Name ":"Ali",
#          "marks": {
#              "Phy ": 89,
#              "Chm ": 78,
#              "Bio ":86
#          }
#          }
# print(student.keys())

# # --------------- Type cast -------------
# student={"Name ":"Ali",
#          "marks": {
#              "Phy ": 89,
#              "Chm ": 78,
#              "Bio ":86
#          }
#          }
# print(list(student))
# print(type(student))

# # ----------------- len ( ) ---------------
# # Length of Dict === No. of Keys
# student={"Name ":"Ali",
#           "marks": {
#               "Phy ": 89,
#               "Chm ": 78,
#               "Bio ":86
#           }
#        }
# print(len(student))

# # ----------------- Values ( ) -----------------
# # To print all Values of function
# # It will return full dict without keys
# student={"Name ":"Ali",
#           "marks": {
#               "Phy ": 89,
#               "Chm ": 78,
#               "Bio ":86
#           }
#        }
# print(student.values())

# # ----------------- Items ( ) ---------------
# student={"Name ":"Ali",
#           "marks": {
#               "Phy ": 89,
#               "Chm ": 78,
#               "Bio ":86
#           }
#        }
# print(student.items())

# # --------------- Get ( ) ----------------
# # The  ways to return Values : 
# # 1 . print(dict_name.get("Key_name"))
# # 2 . print(dict_name["key_name"])
# student={"Name ":"Ali",
#           "marks": {
#               "Phy ": 89,
#               "Chm ": 78,
#               "Bio ":86
#           }
#        }
# print(student["name"]) # In case of Incorrect Key name it will not runs
# print(student.get("Name "))  #In case of Incorrect Key name But it will  runs

# # ------------------- Update ( ) -----------
# # Syntax == > Dict_name.update({Key : Variable})
# student={"Name ":"Ali",
#           "marks": {
#               "Phy ": 89,
#               "Chm ": 78,
#               "Bio ":86
#           }
#        }
# student.update({"City ":"SGD"})
# # ------ Can also add new dict in it
# new={"Province" : "Punjab"}
# student.update(new)
# print(student)
# # ----- Incase of updating old key
# n1={"Name ":"Ahmad"}
# student.update(n1)
# print(student)

# # -------------------------------------------------------------------------------------------------------

# # =================================== Sets ===============================
## Sets are Mutable 
# #But its variables are Immutable
# # To store unordered value 
# # Each variable must be Uniquw and not changeable
# # It will Print un orderly
# # list and Dict are not storable in set as they are mUTABLE
# num={1,2,3,4,5,6}
# print(type(num))
# print(num)
# # ------- Strings in set
# num={1,2,3,4,5,6,"Hello","Ahmad"}
# print(type(num))
# print(num)
# # Incase of a variable repeatition it will ignores and returns one time
# num={1,2,3,4,5,6,1,2,3,4,5,6,}
# print(type(num))
# print(num)

# # ------------------------------ InBuilt Functions ----------------
# # ---------------- Len ( ) -----------------
# # Length == No. of Vraiables(Without Repeatition)
# num={1,2,3,4,5,6,1,2,3,4,5,6,}
# print(num)
# print(len(num))

# # ----------------- Empty set ----------------
# # In this case its data type is Dict
# emptyset={}
# print(type(emptyset))
# # In this case its data type is Set
# empty=set()
# print(type(empty))

# # ------------------------- add ( ) -----------------------
# # Sets are Mutable 
# # But its variables are Immutable
# num={1,2,3,4,5,6,1,2,3,4,5,6,}
# num.add("Hello")
# # Ignores duplicate add Value
# num.add("Hello")
# print(num)

# # ------------------------- Remove ( ) -----------------------
# num={1,2,3,4,5,6,1,2,3,4,5,6,}
# num.remove(1)
# # It will removes variables
# # Not exit variable if removed show error 
# print(num)

# # -------------------------- Clear ( ) -------------------
# # Emptys the set
# # In case of Variable Taking set gives === >> set()
# num={1,2,3,4,5,6,1,2,3,4,5,6,}
# num.clear()
# print(num)
# # In case of already empty set === >> none
# set1=set()
# print(set1.clear())

# # ------------------------- Pop ( ) ----------------------
# # Removes variable randomly
# # It index not exists it will returns error
# num={1,2,3,4,5,6,1,2,3,4,5,6,}
# print(num.pop()) # returns removing variable
