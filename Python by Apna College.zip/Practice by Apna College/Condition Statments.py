# ============== Detail on if elif and else =================
# =================== If else ==================
# #============ Task 1
# age=int(input("Enter Your Age : "))
# if(age>=18):
#     print("You have now right to cast vote ")
# else:
#     print("You are under 18 and have no right to cast vote")
# # Condition Variable <,>,<=,>= and ==
# # Return in bool
# # ========== Task 2
# print(age>18)
# print(age<18)
# print(age==18)
# print(age<=18)
# print(age>=18)
# # ========== Task 3
# b=float(input("Enter Budget : "))
# if(b>=210):
#     print("Add 1KG Apple to Cart ")
# else:
#     print("Do not Add 1KG Apple to Cart ")
# ====================== Else if ================
# # ============= Task 1
# b=float(input("Enter Your Budger : "))
# p=float(input("Enter Price of Apple 1 KG : "))
# if(b-p>=50):
#     print("Add 1 KG Apple To cart ")
# elif(b-p>=40):
#     print("Its okay buy 1 KG Apple ")
# else:
#     print("I am not going to Buy 1 KG Apple ")
# # ============= Task 2
# num=int(input("Enter the Num : "))
# if(num>0):
#     print(num, " is Positive Number ")
# elif(num==0):
#     print("Num is Zero")
# else:
#     print(num," is Negative Number")
# ====================== Nested if else ================
# # Task 1 ========================
# day=int(input("Enter day : "))
# mon=int(input("Enter Month : "))
# year=int(input("Enter Year : "))
# if(mon%2!=0):
#     if(day<=31):
#         print("Date : ",day," - ",mon," - ",year)
#     else:
#         print("Invalid input of No of Days : ",day)

# elif(mon==2):
#     if(year%4==0):
#         if(day<=29):
#             print("Its a Leap Year")
#             print("Date : ",day," - ",mon," - ",year)
#         else:
#             print("Invalid input of No of Days in Febauary : ",day)
#     else:
#         if(day<=28):
#             print("Its Not a Leap Year")
#             print("Date : ",day," - ",mon," - ",year)
#         else:
#             print("Invalid input of No of Days in Febauary : ",day)

# else:
#     if(day<=30):
#          print("Date : ",day," - ",mon," - ",year)
#     else:
#         print("Invalid input of No of Days : ",day)