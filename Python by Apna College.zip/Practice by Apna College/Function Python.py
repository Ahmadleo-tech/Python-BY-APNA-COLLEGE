# # Function is Block of statment that perform a specific task
# # -------- Task 1 -------
# def sum(a,b):
#     s=a+b
#     return s
# print(sum(234,13))

# # -------------------------------------------------------
# # The argument and perimeters are the same variable :
# # But Argumnets are value given in function when its called
# # The variables which were given to function when its created
# # -------------------------------------------------------

# # # ------- Task 2 ----------
# def sum(a,b):
#     return a+b
# def sub(a,b):
#     return a-b
# def mult(a,b):
#     return a*b
# def div(a,b):
#     if(b==0):
#         print("The Divison Operation is Not Possibe as Value of B is : ",b)
#     else:
#         return a/b
# print("Menue : \n1 . Addition \n2 . Subrtaction \n3 . Multiplcation \n4 .Division \n5 . Exit ")
# choice=int(input("Enter Choice from ( 1 - 5 ) : "))
# match choice:
#     case 1:
#         a=int(input("Enter Number 1 : "))
#         b=int(input("Enter Number 2 : "))
#         print("Sum of ",a," and ",b," is : ",sum(a,b))
#     case 2:
#         a=int(input("Enter Number 1 : "))
#         b=int(input("Enter Number 2 : "))
#         print("Subtraction of ",a," and ",b," is : ",sub(a,b))
#     case 3:
#         a=int(input("Enter Number 1 : "))
#         b=int(input("Enter Number 2 : "))
#         print("Product of ",a," and ",b," is : ",mult(a,b))
#     case 4:
#         a=int(input("Enter Number 1 : "))
#         b=int(input("Enter Number 2 : "))
#         print("Division of ",a," and ",b," is : ",div(a,b))
#     case 5:
#         print("Success Fuly Exited ")
#     case _:
#         print("Invalid Input ")

# # # ------- Task 3 ----------
# def avg(a,b,c):
#     a1=a+b+c
#     av=a1/3
#     return av
# n1=int(input("Enter Number 1 : "))
# n2=int(input("Enter Number 2 : "))
# n3=int(input("Enter Number 3 : "))
# print("Average : ",avg(n1,n2,n3))

# # # ------- Task 4 ---------- ( Default Value )
# # ------ P1 
# def product(a=1,b=1):
#     print(a*b)
# product()
# # ----- P2 ( Starts passing default values passing from end)
# def product(a,b=1):
#     print(a*b)
# product(5)

# # ------------------------------------------------------------------------
# # ----- Task 1
# cities=["Ali","Ahmad","harry","Potter"]
# def lent(list):
#     print("Length of  list : ",len(list))
# hero=["IR","Hulk","Caption","Thor"]
# lent(hero)
# lent(cities)

# # ------- Task 2
# def pr(list):
#     for i in list:
#         print(i,end=" ")
# name=["Ali","Ahmad","harry","Potter"]
# hero=["IR","Hulk","Caption","Thor"]
# pr(hero)
# pr(name)

# # # ------- Task 3
# def fact(n):
#     fac=1
#     for i in range(1, n+1):
#         fac*=i
#     print("Factorial of ",n," is : ",fac)

# fact(12)

# # # ------- Task 4
# def conv(usd):
#     pkr=usd*278
#     print(usd," are converted in PKR : ",pkr)

# usd=float(input("Enter USD you wanted to convert in PKR : "))
# conv(usd)

# # # ------- Task 5
# def check(a):
#     if(a%2==0):
#         print(a," is an Even Number : ")
#     else:
#         print(a," is an Odd Number ")

# a=int(input("Enter Number : "))
# check(a)