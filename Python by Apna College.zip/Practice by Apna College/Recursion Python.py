# # Recurrsion ==== >> Functions Calls it self
# # # --------- Task 1 -----------
# def show(a):
#     if(a==0): # Base Case
#         return
#     print(a)
#     show(a-1)

# show(6)

# # # --------- Task 2 -----------
# def fact(n):
#     if(n==1 or n==0):
#         return 1
#     else:
#         return fact(n-1)*n
    
# print(fact(5))

# # # # --------- Task 3 -----------
# def sum(n):
#     if(n==0):
#         return 0
#     return sum(n-1)+n

# print(sum(9))

# # # --------- Task 4 -----------
# list1=["ali","ahmad","harr6","neon"]
 
# def pri(l,i=0):
#     if(i==len(l)):
#         return
#     print(l[i])
#     pri(l,i+1)

# pri(list1)
